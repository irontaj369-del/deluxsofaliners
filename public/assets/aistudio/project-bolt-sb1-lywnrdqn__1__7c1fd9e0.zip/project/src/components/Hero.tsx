import { useEffect, useState } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight, MessageCircle, Scissors, Star } from 'lucide-react';

const WHATSAPP_LINK = 'https://wa.me/919703701756?text=Send%20photo%20for%20fast%20estimate';

const SLIDES = [
  {
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc',
    alt: 'Luxury modern living room with custom sofa set',
    eyebrow: 'Made-to-order furniture studio',
  },
  {
    image: 'https://images.pexels.com/photos/4173274/pexels-photo-4173274.jpeg?auto=compress&cs=tinysrgb&h=1200&w=1600',
    alt: 'Expert craftsman re-upholstering a premium armchair',
    eyebrow: 'Hands-on restoration craftsmanship',
  },
  {
    image: 'https://images.pexels.com/photos/7546281/pexels-photo-7546281.jpeg?auto=compress&cs=tinysrgb&h=1200&w=1600',
    alt: 'Elegant padded wall panel behind a bed headboard',
    eyebrow: 'Luxury wall and bed backrest panels',
  },
];

export default function Hero() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => setActive((current) => (current + 1) % SLIDES.length), 6000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <section id="home" className="relative isolate min-h-[680px] overflow-hidden bg-navy-800 text-cream-50">
      {SLIDES.map((slide, index) => (
        <div
          key={slide.image}
          className={`absolute inset-0 transition-opacity duration-1000 ${index === active ? 'opacity-100' : 'opacity-0'}`}
          aria-hidden={index !== active}
        >
          <img src={slide.image} alt={slide.alt} className="h-full w-full object-cover" loading={index === 0 ? 'eager' : 'lazy'} />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-800/95 via-navy-800/75 to-navy-800/25" />
        </div>
      ))}

      <div className="relative mx-auto flex min-h-[680px] max-w-7xl items-center px-4 pb-24 pt-32 sm:px-6 lg:px-8">
        <div className="max-w-3xl animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full border border-accent-400/30 bg-navy-800/40 px-3.5 py-1.5 text-xs font-bold uppercase tracking-[0.16em] text-accent-400 backdrop-blur-sm">
            <Scissors className="h-3.5 w-3.5" />
            {SLIDES[active].eyebrow}
          </span>
          <h1 className="mt-6 text-4xl font-extrabold leading-[1.08] tracking-tight sm:text-6xl lg:text-7xl">
            Bespoke Sofas, Expert Repair &amp; Luxury Wall Panel Craftsmanship
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-cream-200 sm:text-xl">
            Handcrafted custom sofa sets, complete furniture restoration, and premium bed backrest &amp; acoustic wall paneling in Basheer Bagh, Hyderabad.
          </p>
          <div className="mt-9 flex flex-col gap-3.5 sm:flex-row">
            <a href="#contact" className="group inline-flex items-center justify-center gap-2 rounded-full bg-accent-500 px-6 py-3.5 text-base font-bold text-white shadow-lg shadow-black/20 transition-all hover:-translate-y-0.5 hover:bg-accent-600">
              Get Free Doorstep Estimate
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-2 rounded-full border border-white/25 bg-white/10 px-6 py-3.5 text-base font-bold text-white backdrop-blur-sm transition-all hover:bg-white/20">
              <MessageCircle className="h-4 w-4 text-[#25D366]" />
              WhatsApp Photo for Quote
            </a>
          </div>
          <div className="mt-8 flex items-center gap-3 text-sm text-cream-200">
            <div className="flex gap-0.5 text-accent-400">{[0, 1, 2, 3, 4].map((star) => <Star key={star} className="h-4 w-4 fill-current" />)}</div>
            <span><strong className="text-white">4.3-star rated</strong> local craftsmanship</span>
          </div>
        </div>
      </div>

      <div className="absolute bottom-7 left-4 right-4 flex items-center justify-between sm:left-1/2 sm:right-auto sm:w-[calc(100%-2rem)] sm:max-w-7xl sm:-translate-x-1/2 sm:px-6 lg:px-8">
        <div className="flex gap-2">
          {SLIDES.map((slide, index) => <button key={slide.image} onClick={() => setActive(index)} className={`h-1.5 rounded-full transition-all ${index === active ? 'w-10 bg-accent-400' : 'w-5 bg-white/40'}`} aria-label={`Show slide ${index + 1}`} />)}
        </div>
        <div className="flex gap-2">
          <button onClick={() => setActive((active - 1 + SLIDES.length) % SLIDES.length)} className="flex h-10 w-10 items-center justify-center rounded-full border border-white/25 bg-white/10 text-white backdrop-blur-sm hover:bg-white/20" aria-label="Previous slide"><ChevronLeft className="h-5 w-5" /></button>
          <button onClick={() => setActive((active + 1) % SLIDES.length)} className="flex h-10 w-10 items-center justify-center rounded-full border border-white/25 bg-white/10 text-white backdrop-blur-sm hover:bg-white/20" aria-label="Next slide"><ChevronRight className="h-5 w-5" /></button>
        </div>
      </div>
    </section>
  );
}
