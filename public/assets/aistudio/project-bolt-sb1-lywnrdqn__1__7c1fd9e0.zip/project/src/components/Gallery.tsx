const IMAGES = [
  {
    src: 'https://images.pexels.com/photos/13005211/pexels-photo-13005211.jpeg?auto=compress&cs=tinysrgb&h=700&w=900',
    alt: 'Tufted grey chesterfield sofa upholstery',
    span: 'sm:col-span-2 sm:row-span-2',
  },
  {
    src: 'https://images.pexels.com/photos/13169786/pexels-photo-13169786.jpeg?auto=compress&cs=tinysrgb&h=500&w=600',
    alt: 'Velvet sofa against a green wall',
    span: '',
  },
  {
    src: 'https://images.pexels.com/photos/6480707/pexels-photo-6480707.jpeg?auto=compress&cs=tinysrgb&h=500&w=600',
    alt: 'Minimalist living room with leather sofa',
    span: '',
  },
  {
    src: 'https://images.pexels.com/photos/10410095/pexels-photo-10410095.jpeg?auto=compress&cs=tinysrgb&h=500&w=600',
    alt: 'Rich blue velvet cushion texture',
    span: '',
  },
  {
    src: 'https://images.pexels.com/photos/15602702/pexels-photo-15602702.jpeg?auto=compress&cs=tinysrgb&h=500&w=600',
    alt: 'Brown leather sofa in a cozy living room',
    span: '',
  },
];

export default function Gallery() {
  return (
    <section id="gallery" className="py-20 md:py-28 bg-cream-100/60">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-accent-600">
            Our Work
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl font-extrabold tracking-tight text-navy-700">
            A Glimpse of Recent Projects
          </h2>
          <p className="mt-4 text-lg text-charcoal-500 leading-relaxed">
            Fabrics, finishes, and restorations we've crafted for homes across Hyderabad.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 auto-rows-[10rem] sm:auto-rows-[12rem]">
          {IMAGES.map((img) => (
            <figure
              key={img.src}
              className={`group relative overflow-hidden rounded-2xl ring-1 ring-cream-200 shadow-sm ${img.span}`}
            >
              <img
                src={img.src}
                alt={img.alt}
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-700/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <figcaption className="absolute bottom-0 left-0 right-0 p-3 text-xs font-medium text-cream-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                {img.alt}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
