import { useEffect, useState } from 'react';
import { Phone, Menu, X, Sofa } from 'lucide-react';

const NAV_LINKS = [
  { label: 'Home', href: '/' },
  { label: 'Custom Sofas', href: '/new-sofas' },
  { label: 'Repair & Restoration', href: '/sofa-repair' },
  { label: 'Wall & Bed Panels', href: '/wall-bed-panels' },
  { label: 'Contact & Visit', href: '/contact' },
];

const PHONE_DISPLAY = '097037 01756';
const PHONE_HREF = 'tel:+919703701756';

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={[
        'fixed top-0 inset-x-0 z-50 transition-all duration-300',
        scrolled
          ? 'bg-navy-800/95 backdrop-blur-md shadow-[0_8px_30px_rgba(16,23,40,0.18)]'
          : 'bg-gradient-to-b from-black/80 via-black/45 to-transparent',
      ].join(' ')}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 md:h-20 items-center justify-between">
          {/* Logo */}
          <a href="/" className="flex items-center gap-2.5 group">
            <span className="flex h-9 w-9 md:h-10 md:w-10 items-center justify-center rounded-xl bg-navy-600 text-cream-50 shadow-sm transition-transform group-hover:scale-105">
              <Sofa className="h-5 w-5" />
            </span>
            <span className="flex flex-col leading-none">
              <span className="text-[15px] md:text-lg font-extrabold tracking-tight text-white">
                Delux Sofa Liners
              </span>
            </span>
          </a>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {NAV_LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="px-3 py-2 text-sm font-medium text-white/90 rounded-lg hover:bg-white/10 hover:text-white transition-colors"
              >
                {l.label}
              </a>
            ))}
          </nav>

          {/* Desktop CTA */}
          <a
            href={PHONE_HREF}
            className="hidden md:inline-flex items-center gap-2 rounded-full bg-accent-500 hover:bg-accent-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition-colors"
          >
            <Phone className="h-4 w-4" />
            Call Now: {PHONE_DISPLAY}
          </a>

          {/* Mobile toggle */}
          <button
            onClick={() => setOpen((v) => !v)}
            className="lg:hidden inline-flex items-center justify-center h-10 w-10 rounded-lg text-white hover:bg-white/10 transition-colors"
            aria-label="Toggle menu"
            aria-expanded={open}
          >
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        className={[
          'lg:hidden overflow-hidden transition-[max-height,opacity] duration-300 ease-out bg-navy-800/98 backdrop-blur-md border-t border-white/10',
          open ? 'max-h-[640px] opacity-100' : 'max-h-0 opacity-0',
        ].join(' ')}
      >
        <nav className="px-4 sm:px-6 py-4 flex flex-col gap-1">
          {NAV_LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="px-3 py-2.5 text-base font-medium text-white/90 rounded-lg hover:bg-white/10 hover:text-white transition-colors"
            >
              {l.label}
            </a>
          ))}
          <a
            href={PHONE_HREF}
            onClick={() => setOpen(false)}
            className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-accent-500 hover:bg-accent-600 px-4 py-3 text-base font-semibold text-white shadow-sm transition-colors"
          >
            <Phone className="h-5 w-5" />
            Call Now: {PHONE_DISPLAY}
          </a>
        </nav>
      </div>
    </header>
  );
}
