import { ArrowRight, Armchair, Hammer, PanelsTopLeft } from 'lucide-react';

const PILLARS = [
  {
    icon: Armchair,
    number: '01',
    title: 'Custom New Sofa Sets',
    href: '/new-sofas',
    description: 'Made-to-order sectionals and statement seating, built around your room, lifestyle, and preferred finish.',
    points: ['L-shape and 3-seater designs', 'Wooden frame construction', 'Italian fabric and leatherette options', 'High-density foam comfort'],
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc',
  },
  {
    icon: Hammer,
    number: '02',
    title: 'Old Sofa Repair & Re-Upholstery',
    href: '/sofa-repair',
    description: 'Thoughtful restoration that brings back structure, comfort, and a fresh finish without replacing what still works.',
    points: ['Sagging cushion renewal', 'Broken spring and frame repair', 'Complete cover replacement', 'Doorstep pickup and delivery'],
    image: 'https://images.pexels.com/photos/4173274/pexels-photo-4173274.jpeg?auto=compress&cs=tinysrgb&h=800&w=1200',
  },
  {
    icon: PanelsTopLeft,
    number: '03',
    title: 'Wall & Bed Backrest Paneling',
    href: '/wall-bed-panels',
    description: 'Tailored upholstered surfaces that add warmth, acoustic comfort, and a refined focal point to your room.',
    points: ['Custom fabric and leatherette padding', 'Acoustic interior accent panels', 'Tufted bed headboard backrests', 'Any wall dimension, no bed frames'],
    image: 'https://images.pexels.com/photos/7546281/pexels-photo-7546281.jpeg?auto=compress&cs=tinysrgb&h=800&w=1200',
  },
];

export default function CoreOfferings() {
  return (
    <section id="services" className="bg-cream-100/60 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-accent-600">Our three specialties</span>
          <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-navy-700 sm:text-4xl">Crafted for the way you live</h2>
          <p className="mt-4 text-lg leading-relaxed text-charcoal-500">From a brand-new sofa made around your space to a cherished piece restored with care, every project starts with a conversation.</p>
        </div>
        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {PILLARS.map((pillar) => {
            const Icon = pillar.icon;
            return (
              <article key={pillar.number} className="group overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-cream-200 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-navy-700/10">
                <div className="relative h-52 overflow-hidden">
                  <img src={pillar.image} alt={pillar.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-800/70 to-transparent" />
                  <span className="absolute left-5 top-5 rounded-full bg-white/90 px-3 py-1 text-xs font-bold text-navy-700">{pillar.number}</span>
                  <Icon className="absolute bottom-5 left-5 h-7 w-7 text-accent-400" />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-navy-700">{pillar.title}</h3>
                  <p className="mt-3 text-[15px] leading-relaxed text-charcoal-500">{pillar.description}</p>
                  <ul className="mt-5 space-y-2">
                    {pillar.points.map((point) => <li key={point} className="flex items-center gap-2 text-sm text-charcoal-600"><span className="h-1.5 w-1.5 rounded-full bg-accent-500" />{point}</li>)}
                  </ul>
                  <a href={pillar.href} className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-navy-600 transition-colors hover:text-accent-600">Explore this service <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" /></a>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
