/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      colors: {
        cream: {
          50: '#FBF9F4',
          100: '#F6F2E9',
          200: '#ECE5D5',
          300: '#DCCFB6',
        },
        navy: {
          500: '#1F2D4A',
          600: '#172237',
          700: '#101728',
          800: '#0A0F1B',
        },
        charcoal: {
          500: '#3A3A3A',
          600: '#2A2A2A',
          700: '#1C1C1C',
        },
        accent: {
          400: '#C89B5A',
          500: '#B8854A',
          600: '#9E6F3C',
        },
      },
      animation: {
        'fade-up': 'fadeUp 0.7s ease-out both',
        'fade-in': 'fadeIn 0.7s ease-out both',
      },
      keyframes: {
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(24px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};
