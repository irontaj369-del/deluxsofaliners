/*
# Create leads table (single-tenant, no auth)

1. New Tables
- `leads`
- `id` (uuid, primary key)
- `full_name` (text, not null) — name of the prospective customer
- `phone` (text, not null) — contact phone number
- `service_needed` (text, not null) — requested service: Repair, New Liners, Re-upholstery, or Other
- `message` (text, nullable) — additional details / dimensions from the customer
- `created_at` (timestamptz, default now())
2. Security
- Enable RLS on `leads`.
- Allow anon + authenticated inserts so the public contact form (anon key) can submit leads.
- Allow anon + authenticated selects/updates/deletes so the business owner can manage leads (single-tenant, no sign-in screen).
*/

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  phone text NOT NULL,
  service_needed text NOT NULL,
  message text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_leads" ON leads;
CREATE POLICY "anon_select_leads" ON leads FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_leads" ON leads;
CREATE POLICY "anon_insert_leads" ON leads FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_leads" ON leads;
CREATE POLICY "anon_update_leads" ON leads FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_leads" ON leads;
CREATE POLICY "anon_delete_leads" ON leads FOR DELETE
  TO anon, authenticated USING (true);